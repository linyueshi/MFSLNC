package com.example.ssmp.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ssmp.domain.Book;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BOOkServiceTest {

    @Autowired
    private BookService bookService;
    @Test
    void  testGETbyid(){
        System.out.println(bookService.getById(4));

    }


    @Test
    void  testsave(){
        Book book=new Book();
        book.setBookname("不晓得");
        book.setBookdesc("+1");
        bookService.save(book);

    }


    @Test
    void  testupdate(){
        Book book=new Book();
        book.setId(15);
        book.setBookname("不晓得");
        book.setBookdesc("+1");
        bookService.updateById(book);

    }

    @Test
    void  testdele(){
        bookService.removeById(19);

    }

    @Test
    void  testgetall(){
        bookService.list();

    }

    @Test
    void  testGETpage(){
        IPage<Book> page=new Page<Book>(2,5);
        bookService.page(page);
        System.out.println(page.getSize());
        System.out.println(page.getRecords());

    }
}
