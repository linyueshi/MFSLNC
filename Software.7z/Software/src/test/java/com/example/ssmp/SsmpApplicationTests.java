package com.example.ssmp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.ssmp.dao.BookDao;
import com.example.ssmp.dao.LncDao;
import com.example.ssmp.dao.LncdDao;
import com.example.ssmp.domain.Book;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsmpApplicationTests {
    @Autowired
    private BookDao bookDao;

    @Test
    void contextLoads(){
       bookDao.selectList(null);

    }

    @Test
    void testsave() {
        Book book=new Book();
        book.setBookname("如何从1开始");
        book.setBookdesc(("0与1的界限是什么"));
        bookDao.insert(book);

    }


    @Test
    void testdelet() {
        bookDao.deleteById(16);

    }


    @Test
    void testinsert() {

    }


    @Test
    void testupdate() {
        Book book=new Book();
        book.setId(12);
        book.setBookname("如何从1开始");
        book.setBookdesc(("0与1的界限是什么"));
        bookDao.updateById(book);

    }


    @Test
    void testfen() {
//拦截器就是动态的帮忙拼接sql语句后面的limit语句
//        分页需要用拦截器，拦截器在配置文件里，需要加@configration在启动项目的时候可以扫描到这个配置
        IPage page=new Page(2,5);
        bookDao.selectPage(page,null);
    }


    @Test
    void testtiaojian() {
        QueryWrapper<Book> qw=new QueryWrapper<Book>();
        qw.like("bookname","1");
        bookDao.selectList(qw);


    }
    @Autowired
    private LncdDao lncdDao;
    @Test
    void testlnc(){
        System.out.println(lncdDao.selectById(1));
    }


}
