package com.example.ssmp.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.ssmp.controller.utils.R;

import com.example.ssmp.domain.Lnc;

import com.example.ssmp.service.LncService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("lncs-lnc")
//这里的books是和浏览器输入的网址是对应的
public class LncController {
    @Autowired
    private LncService  lncService;
    @GetMapping
//    get用来查询
    public R getAll(){
        return new R(true,lncService.list());

    }
    @PostMapping
//    增加post
    public R save( @RequestBody Lnc lnc){

        return new R(lncService.save(lnc));
    }

    @PutMapping
//    修改用put
    public R update(@RequestBody Lnc lnc){
        return new R(lncService.updateById(lnc));
    }

    @DeleteMapping("{id}")
    public R delete(@PathVariable Integer id){
        return new R(lncService.removeById(id));

    }
    @GetMapping("{id}")
    public R getById(@PathVariable Integer id){

        return new R(true,lncService.getById(id));
    }
//    @GetMapping("{currentPage}/{pageSize}")
////    根据id查单个数据
//    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize){
//        IPage<Book> page =bookService.getPage(currentPage,pageSize);
//        if(currentPage>page.getPages()){
//            page=bookService.getPage((int)page.getPages(),pageSize);
//        }
//
//        return new R(true,page);
//
//    }
    @GetMapping("{currentPage}/{pageSize}")
//    根据id查单个数据
    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize,Lnc lnc){
        IPage<Lnc> page =lncService.getPage(currentPage,pageSize,lnc);
        if(currentPage>page.getPages()){
            page=lncService.getPage((int)page.getPages(),pageSize,lnc);
        }

        return new R(true,page);

    }




}
