package com.example.ssmp.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ssmp.domain.Lnc;
import com.example.ssmp.domain.Lncd;

//IService<Book>这一块是mps的操作，里面有一些默认配置好的增删改查  函数
public interface LncdService extends IService<Lncd> {
    IPage<Lncd> getPage(int currentpage, int pageSize);
    IPage<Lncd> getPage(int currentpage, int pageSize, Lncd lncd);

}
