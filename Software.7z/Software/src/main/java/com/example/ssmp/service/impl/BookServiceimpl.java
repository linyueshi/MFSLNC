package com.example.ssmp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ssmp.dao.BookDao;
import com.example.ssmp.domain.Book;
import com.example.ssmp.service.BookService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//Service相当于把他写道xml里了，生产bean(对象)了，可以new了
@Service
public class BookServiceimpl extends ServiceImpl<BookDao, Book> implements BookService {
    @Autowired
    private BookDao bookDao;

    @Override
    public IPage<Book> getPage(int currentpage, int pageSize) {

        IPage page=new Page(currentpage,pageSize);
        bookDao.selectPage(page,null);
        return page;
    }
    @Override
    public IPage<Book> getPage(int currentpage, int pageSize, Book book) {
        LambdaQueryWrapper<Book> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(Strings.isNotEmpty(book.getBookname()),Book::getBookname,book.getBookname());
        lambdaQueryWrapper.like(Strings.isNotEmpty(book.getBookdesc()),Book::getBookdesc,book.getBookdesc());
        IPage page=new Page(currentpage,pageSize);
        bookDao.selectPage(page,lambdaQueryWrapper);
        return page;
    }
}
