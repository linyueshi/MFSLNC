package com.example.ssmp.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.ssmp.dao.LncDao;
import com.example.ssmp.dao.LncdDao;
import com.example.ssmp.domain.Lnc;
import com.example.ssmp.domain.Lncd;
import com.example.ssmp.service.LncService;
import com.example.ssmp.service.LncdService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//Service相当于把他写道xml里了，生产bean(对象)了，可以new了
@Service
public class lncdServiceimpl extends ServiceImpl<LncdDao, Lncd> implements LncdService {
    @Autowired
    private LncdDao bookDao;

    @Override
    public IPage<Lncd> getPage(int currentpage, int pageSize) {

        IPage page=new Page(currentpage,pageSize);
        bookDao.selectPage(page,null);
        return page;
    }
    @Override
    public IPage<Lncd> getPage(int currentpage, int pageSize, Lncd lncd) {
        LambdaQueryWrapper<Lncd> lambdaQueryWrapper=new LambdaQueryWrapper<>();
        lambdaQueryWrapper.like(Strings.isNotEmpty(lncd.getLncrna()),Lncd::getLncrna,lncd.getLncrna());
        lambdaQueryWrapper.like(Strings.isNotEmpty(lncd.getDisease()),Lncd::getDisease,lncd.getDisease());


        IPage page=new Page(currentpage,pageSize);
        bookDao.selectPage(page,lambdaQueryWrapper);
        return page;
    }
}
