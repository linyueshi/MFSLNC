package com.example.ssmp.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.ssmp.domain.Book;
import com.example.ssmp.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("boaks")
//这里的books是和浏览器输入的网址是对应的
public class BookController2 {
    @Autowired
    private BookService bookService;
    @GetMapping
//    get用来查询
    public List<Book> getAll(){
        return bookService.list();
    }
    @PostMapping
//    增加post
    public Boolean save( @RequestBody Book book){
        return bookService.save(book);
    }

    @PutMapping
//    修改用put
    public Boolean update(@RequestBody Book book){
        return bookService.updateById(book);
    }

    @DeleteMapping("{id}")
    public Boolean delete(@PathVariable Integer id){
        return bookService.removeById(id);
    }
//    @GetMapping("{currentPage}/{pageSize}")
//    根据id查单个数据
//    public IPage<Book> getById(@PathVariable int currentPage, @PathVariable int pageSize){
//        IPage<Book> page =bookService.getPage(currentPage,pageSize, book);
//        if(currentPage>page.getPages()){
//            page=bookService.getPage((int)page.getPages(),pageSize, book);
//        }
//
//
//        return bookService.getPage(currentPage,pageSize, book);
//    }




}
