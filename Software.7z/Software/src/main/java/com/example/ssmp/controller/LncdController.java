package com.example.ssmp.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.ssmp.controller.utils.R;
import com.example.ssmp.domain.Lncd;
import com.example.ssmp.service.LncdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("lncd-d")
//这里的books是和浏览器输入的网址是对应的
public class LncdController {
    @Autowired
    private LncdService  lncdService;
    @GetMapping
//    get用来查询
    public R getAll(){
        return new R(true,lncdService.list());

    }
    @PostMapping
//    增加post
    public R save( @RequestBody Lncd lncd){

        return new R(lncdService.save(lncd));
    }

    @PutMapping
//    修改用put
    public R update(@RequestBody Lncd lncd){
        return new R(lncdService.updateById(lncd));
    }

    @DeleteMapping("{id}")
    public R delete(@PathVariable Integer id){
        return new R(lncdService.removeById(id));

    }
    @GetMapping("{id}")
    public R getById(@PathVariable Integer id){

        return new R(true,lncdService.getById(id));
    }
//    @GetMapping("{currentPage}/{pageSize}")
////    根据id查单个数据
//    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize){
//        IPage<Book> page =bookService.getPage(currentPage,pageSize);
//        if(currentPage>page.getPages()){
//            page=bookService.getPage((int)page.getPages(),pageSize);
//        }
//
//        return new R(true,page);
//
//    }
    @GetMapping("{currentPage}/{pageSize}")
//    根据id查单个数据
    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize,Lncd lncd){
        IPage<Lncd> page =lncdService.getPage(currentPage,pageSize,lncd);
        if(currentPage>page.getPages()){
            page=lncdService.getPage((int)page.getPages(),pageSize,lncd);
        }

        return new R(true,page);

    }




}
