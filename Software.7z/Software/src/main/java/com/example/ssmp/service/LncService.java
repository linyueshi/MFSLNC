package com.example.ssmp.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.ssmp.domain.Book;
import com.example.ssmp.domain.Lnc;

//IService<Book>这一块是mps的操作，里面有一些默认配置好的增删改查  函数
public interface LncService extends IService<Lnc> {
    IPage<Lnc> getPage(int currentpage, int pageSize);
    IPage<Lnc> getPage(int currentpage, int pageSize, Lnc lnc);

}
