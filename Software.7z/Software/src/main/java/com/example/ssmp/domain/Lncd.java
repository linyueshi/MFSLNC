package com.example.ssmp.domain;
//lombok就是帮你写好了get、set、tostring方法的一个注解
import lombok.Data;

@Data
//@Data是lombok中可以替你补充  get()、 set()、 toString()方法的注释
//ctrl+12查看这个类里面的方法
public class Lncd {
    private Integer id;
    private String lncrna;
    private String disease;
    private float  value;

}
