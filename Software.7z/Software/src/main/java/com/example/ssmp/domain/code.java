package com.example.ssmp.domain;




import java.util.*;

import java.util.HashMap;
import java.util.Map;

public class code {

    public static void main(String[] args) {
        String str = "ACGTACT";
        ArrayList<String> str1 = new ArrayList<>();
        Map<String,Float> map = new HashMap<String,Float>();
        Map<String,Float> map1 = new HashMap<String,Float>();
        Map<String,Float> map2 = new HashMap<String,Float>();
        Map<String,Float> map3 = new HashMap<String,Float>();



        for (int k = 1; k <4 ; k++) {
            for (int x = 0; x < str.length()-k+1; x ++) {
                str1.add(str.substring(x,x+k));

            }

        }

        int[] number=new int[str1.size()];
        for (int i = 0; i < str1.size(); i++) {
            int count=1;
            for (int j = 0; j < str1.size(); j++) {

                if(str1.get(i).equals(str1.get(j)))
                    number[i]= count++;


            }

        }
        for (int i = 1; i < number.length; i++) {
            map.put(str1.get(i),Float.valueOf(number[i])/str.length());
        }
        System.out.println(map);


        for (Map.Entry<String, Float> entry : map.entrySet()) {
            String mapKey = entry.getKey();
            if (mapKey.length()!=1){
                String mapKeySub = mapKey.substring(0,mapKey.length()-1);
                Float mapValueSub = map.get(mapKeySub);
                map1.put(mapKey,entry.getValue()/mapValueSub);
            }
            else {
                map1.put(mapKey, entry.getValue());
            }
        }
        System.out.println(map1);




        for (Map.Entry<String, Float> entry : map.entrySet()) {
            String mapKey = entry.getKey();

            for (Map.Entry<String, Float> entry1 : map1.entrySet()) {
                String mapKey1 = entry1.getKey();
                if(mapKey==mapKey1){
                    Float S=Math.min(entry.getValue(),entry1.getValue());
                    map2.put(mapKey, S);
                }


            }


        }

        System.out.println(map2);
        for (Map.Entry<String, Float> entry : map.entrySet()) {
            String mapKey = entry.getKey();

            for (Map.Entry<String, Float> entry1 : map1.entrySet()) {
                String mapKey1 = entry1.getKey();
                if(mapKey==mapKey1){
                    Float S=Math.max(entry.getValue(),entry1.getValue());
                    map3.put(mapKey, S);
                }
                else {
                    map3.put(mapKey1,entry1.getValue());
                }


            }


        }
        System.out.println(map3);
//        ***************交求模***************
        Collection<Float> S1=map2.values();
        Float SumTop=0f;
        for (Float f :S1 ) {
            SumTop+=Float.valueOf((float) Math.pow(f,2));
    }
        SumTop=Float.valueOf((float) Math.sqrt(SumTop));
        //        ***************并求模***************

        Collection<Float> S2=map3.values();
        Float SumBootem=0f;
        for (Float f :S2 ) {
            SumBootem+=Float.valueOf((float) Math.pow(f,2));
        }
        SumBootem=Float.valueOf((float) Math.sqrt(SumBootem));


        System.out.println(SumTop);
        System.out.println(SumBootem);
    }

}
