package com.example.ssmp.dao;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.ssmp.domain.Lnc;
import com.example.ssmp.domain.Lncd;
import org.apache.ibatis.annotations.Mapper;

//我们这里的Dao其实就是某些视频里的mapper层
@Mapper
//Mapper实际上是将数据库中的字段与类属性映射的一个注解，它是mp的内容，而mps的功能在下一步，就是不用写selet等sql语句。这也在侧面说明了mps其实就是在简化mp的开发
// BaseMapper<Book>这一块是mps的内容
public interface LncdDao extends BaseMapper<Lncd> {
//    mps里面封装了很多功能，但是如果你需要的里面没有。你可以在这里接着写
}
