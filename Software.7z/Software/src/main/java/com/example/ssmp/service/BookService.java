package com.example.ssmp.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;

import com.example.ssmp.domain.Book;
//IService<Book>这一块是mps的操作，里面有一些默认配置好的增删改查  函数
public interface BookService extends IService<Book> {
    IPage<Book> getPage(int currentpage, int pageSize);
    IPage<Book> getPage(int currentpage, int pageSize, Book book);

}
