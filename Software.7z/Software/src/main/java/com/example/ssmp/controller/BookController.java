package com.example.ssmp.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.example.ssmp.controller.utils.R;
import com.example.ssmp.domain.Book;
import com.example.ssmp.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("books")
//这里的books是和浏览器输入的网址是对应的
public class BookController {
    @Autowired
    private BookService bookService;
    @GetMapping
//    get用来查询
    public R getAll(){
        return new R(true,bookService.list());

    }
    @PostMapping
//    增加post
    public R save( @RequestBody Book book){

        return new R(bookService.save(book));
    }

    @PutMapping
//    修改用put
    public R update(@RequestBody Book book){
        return new R(bookService.updateById(book));
    }

    @DeleteMapping("{id}")
    public R delete(@PathVariable Integer id){
        return new R(bookService.removeById(id));

    }
    @GetMapping("{id}")
    public R getById(@PathVariable Integer id){

        return new R(true,bookService.getById(id));
    }
//    @GetMapping("{currentPage}/{pageSize}")
////    根据id查单个数据
//    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize){
//        IPage<Book> page =bookService.getPage(currentPage,pageSize);
//        if(currentPage>page.getPages()){
//            page=bookService.getPage((int)page.getPages(),pageSize);
//        }
//
//        return new R(true,page);
//
//    }
    @GetMapping("{currentPage}/{pageSize}")
//    根据id查单个数据
    public R getPage(@PathVariable int currentPage, @PathVariable int pageSize,Book book){
        IPage<Book> page =bookService.getPage(currentPage,pageSize,book);
        if(currentPage>page.getPages()){
            page=bookService.getPage((int)page.getPages(),pageSize,book);
        }

        return new R(true,page);

    }




}
